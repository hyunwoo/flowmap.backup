import processing.core.*; 
import processing.data.*; 
import processing.opengl.*; 

import processing.pdf.*; 
import java.awt.event.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class HistoryCircle extends PApplet {




String keyword = "gun";

boolean savePdf = false;


public void draw() {




  if (savePdf)
  {
    beginRecord(PDF, "flow_circle_" +frameCount + ".pdf");
  } 
  background(0);
  // text("fps  " + Integer.toString((int)frameRate), width - 150, 20);

  translate(widthC*0.5f, height*0.5f);

  drawFlow();
  highlightCircosName.clear();
  if (C_flag)drawCircos();
  if (M_flag)drawMDS();

  uIDraw();
  textDraw();

  if (savePdf)
  {
    endRecord();
    noLoop();
    savePdf = false;
  }
  // endRecord();
  //noLoop();

  //saveFrame("line-######.png");
}

String[] lastText;

ArrayList vertexList;
ArrayList versionList;
ArrayList vertexNameList;
ArrayList versionNameList;
ArrayList mdsStrList;
ArrayList mdsNodeList;
ArrayList mdsVersionList;
ArrayList circosList;

int[] versionIndex;
int versionCnt = -1;
int widthC=1150;
boolean samplingViewState = false;

int sortCnt = 0;
public void setup() {
  size(1350, 900, P2D);
  inputData();
}

int[] lastColorArr;
int[] lastColorHighListArr;

int highlistVersion = -2;
String highlistName;

float rad = 180f;
float scaleRatio = 1.0f;
int lastDistance=0;
public void inputData() {

  vertexList = new ArrayList();
  vertexNameList = new ArrayList();
  versionList = new ArrayList();
  mdsStrList = new ArrayList();
  mdsNodeList = new ArrayList();
  mdsVersionList = new ArrayList();
  versionNameList = new ArrayList();

  circosList = new ArrayList();

  String[] lines = loadStrings(keyword + "/drawData.txt");
  versionIndex = new int[3000];
  lastText=loadStrings(keyword + "/lastVersion.txt");
  for (int index=0; index<lastText.length;index++)
  {
    lastTextLength+=lastText[index].length();
    lastDistance+=10*((int)(lastText[index].length()/60))+10;
  }
  lastDistance-=(height*0.5f);
  int lastVersionCnt = 0;
  int lastVersion = 0;


  for (int index = 0; index < lines.length; index++)
  {
    float[] vertexArr = new float[5];
    String[] pieces = split(lines[index], ',');

    lastVersionCnt++;


    //println(pieces.length);

    if (pieces.length !=1) {
      vertexNameList.add(pieces[0]);

      for (int i = 2 ; i < 6 ; ++i) {
        vertexArr[i-2] = Float.parseFloat(pieces[i]);
      }


      float tempVersion = (float)Integer.parseInt(pieces[1]);

      vertexArr[4] = tempVersion;

      //print(pieces[0]);
      vertexList.add(vertexArr);
      versionIndex[versionCnt]++;
    }
    else {
      // println(versionIndex[versionCnt]);
      //versionIndex[versionCnt]++;

      versionNameList.add(lines[index]);

      int tempNameCnt = -1;
      for (int j= 0 ; j < nameRatioCnt ; ++j) {
        if (lines[index].equals(nameRatioList[j].name)) {
          tempNameCnt = j;
          nameRatioList[tempNameCnt].count++;
          break;
        }
      }       
      if (tempNameCnt==-1)nameRatioList[nameRatioCnt++] = new NameRatioList(lines[index], 1);

      //println(lines[index]);
      versionCnt++;
      lastVersionCnt = 0;
      lastVersion = vertexNameList.size();
    }
  }
  println(versionCnt);
  endVersion = versionCnt;


  String[] mdsLines = loadStrings(keyword + "/MDS.txt");

  int oldIndex = -1;
  boolean mdsListState = false;
  int mdsVersion = 0;
  for (int index = 0; index < mdsLines.length; index++)
  {
    if (index%3==0) {

      int inputIndex = Integer.parseInt(mdsLines[index]);
      if (oldIndex!=inputIndex) {
        oldIndex = inputIndex;
        mdsListState = true;
      }
      //mdsVersionList[]
    }
    else if (index%3==1) {
      //String[] pieces2 = split(mdsLines[index], " ");
      mdsStrList.add(mdsLines[index]);
    }
    else {
      String[] pieces = split(mdsLines[index], '\t');
      PVector mdsVector = new PVector();
      if (keyword =="gun") {
        mdsVector.x = (Float.parseFloat(pieces[0]) - 1.3f) * 0.8f;
        mdsVector.y = (Float.parseFloat(pieces[1]) - 0.85f) * 0.8f;
      }
      else {
        mdsVector.x = (Float.parseFloat(pieces[0]) - 1.0f) * 0.9f;
        mdsVector.y = (Float.parseFloat(pieces[1]) - 2.1f) * 0.9f;
      }
      mdsVector.z = mdsVersion;
      //println(mdsVector.x);
      mdsNodeList.add(mdsVector);
      if (mdsListState) {
        mdsVersionList.add(mdsVector);
        mdsListState = false;
        mdsVersion++;
      }
    }
  }


  String[] circosLines = loadStrings("health/drawCircos.txt");

  for (int index = 0; index < circosLines.length; index++)
  {
    String[] pieces = split(circosLines[index], ',');
    int[] circosArr = new int[2];

    circosArr[0] = Integer.parseInt(pieces[0]);
    circosArr[1] = Integer.parseInt(pieces[1]);
    circosList.add(circosArr);
  }
  noStroke();

  println(versionNameList.size());
  uiSetup() ;

  addMouseWheelListener(new MouseWheelListener() { 
    public void mouseWheelMoved(MouseWheelEvent mwe) { 
      mouseWheel(mwe.getWheelRotation());
    }
  }
  );

  if (lastColorArr == null) {


    lastColorArr = new int[lastVersionCnt];
    lastColorHighListArr =  new int[lastVersionCnt];

    for (int i = 0 ; i < lastVersionCnt ; ++i) {
      float[] lastVertexArr = (float[])vertexList.get(lastVersion+i);
      int colorVersion = (int)(lastVertexArr[4]);

      PVector mdsNode = (PVector)mdsVersionList.get(colorVersion/2);

      int quadColor = searchColor(mdsNode, -1, -1);
      lastColorArr[i] = quadColor;
      lastColorHighListArr[i] = colorVersion/2;
    }
  }

  for (int i=0 ; i < 1000 ; ++i) {
    for (int j= 0 ; j < nameRatioCnt ; ++j) {
      if (nameRatioList[j].count == i) {
        nameRatioList[j].sortNum = sortCnt;
        sortCnt++;
      }
    }
  }
}


ArrayList highlightCircosName = new ArrayList();
public void drawCircos() {

  float circosRad = rad-10;
  stroke(255, 50);
  strokeWeight(1f);
  noFill();
  for (int i = 0 ; i < circosList.size(); ++i) {

    int[] circosArr = (int[])circosList.get(i);

    if (circosArr[0] < startVersion)continue;
    if (circosArr[1] > endVersion)continue;

    if ((circosArr[0] %2!=1) || (circosArr[1] %2!=1))continue;

    float angle_1 = 2f * PI / (float)(endVersion - startVersion) * 
      (float)(circosArr[0]) - 0.5f*PI;

    float angle_2 = 2f * PI / (float)(endVersion - startVersion) * 
      (float)(circosArr[1]) - 0.5f*PI;

    PVector mdsNode = (PVector)mdsVersionList.get(circosArr[0]/2);

    //color quadColor = yuvToRgb(mdsNode, -1, -1);

    int quadColor = searchColor(mdsNode, -1, -1);
    if (!H_flag &&circosArr[1] == highlistVersion) {
      stroke(quadColor, 255f);
      strokeWeight(2f);
      highlightCircosName.add(circosArr);
    }
    else {
      strokeWeight(1f);
      stroke(quadColor, 30f);
      if (pressed_9)continue;
    }


    String versionName1 = (String)versionNameList.get(circosArr[0]/2);
    String versionName2 = (String)versionNameList.get(circosArr[1]/2);



    //line(circosRad * cos(angle_1), circosRad * sin(angle_1), 
    //circosRad * cos(angle_2), circosRad * sin(angle_2));
    float versionDiff = 1.0f - 1f*(float)(circosArr[0] - circosArr[1]) / (float)(endVersion - startVersion);
    versionDiff%=((endVersion - startVersion)*0.5f);
    //println(versionDiff);
    versionDiff *=versionDiff;

    float inderRadius = (float)(endVersion - startVersion)/(float)versionCnt;
    inderRadius=sqrt(inderRadius);
    bezier(circosRad * cos(angle_1), circosRad * sin(angle_1), 
    inderRadius*versionDiff*circosRad * cos(angle_1*0.75f+angle_2*0.25f), 
    inderRadius* versionDiff*circosRad * sin(angle_1*0.75f+angle_2*0.25f), 
    inderRadius*versionDiff*circosRad * cos(angle_1*0.25f+angle_2*0.75f), 
    inderRadius* versionDiff*circosRad * sin(angle_1*0.25f+angle_2*0.75f), 
    circosRad * cos(angle_2), circosRad * sin(angle_2));
  }
}
class NameRatioList {
  String name;
  int count;
  int sortNum;
  public NameRatioList(String _name, int _count) {
    name = _name;
    count = _count;
    sortNum = 0;
  }
}


NameRatioList[] nameRatioList = new NameRatioList[1000];
int nameRatioCnt;
int nameListScroll=0;
public void drawFlow() {


  noStroke();
  nameList=0;
  boolean hightLightState = false;

  float rMouse = sqrt((mouseX - widthC*0.5f)*(mouseX - widthC*0.5f) 
    + (mouseY - height*0.5f)*(mouseY - height*0.5f));

  float r_theta = atan2((mouseY - height*0.5f), (mouseX - widthC*0.5f)) ;
  if (mouseX < widthC*0.5f && mouseY < height*0.5f) {
    r_theta+=2*PI;
    r_theta%=2*PI;
  }

  int version = 0;
  int drawCnt = 0;

  fill(20);
  ellipse(0, 0, 2f*(180f*scaleRatio + rad), 2f*(180f*scaleRatio + rad));


  for (int i = startVersion ; i <endVersion ; i+=2) {
    float angle_1 = 2f * PI / (float)(endVersion - startVersion) * 
      (float)(i) - 0.5f*PI;

    stroke(200, 10);
    strokeWeight(1f);
    line(rad * cos(angle_1), rad * sin(angle_1), 
    350f * cos(angle_1), 350f * sin(angle_1));
  }

  noStroke();

  float angle_1 = 2f * PI / (float)(endVersion -startVersion ) * 
    (float)(version -startVersion) - 0.5f*PI;
  float angle_2 = 2f * PI / (float)(endVersion -startVersion ) * 
    (float)(version -startVersion +1) - 0.5f*PI;


  float cosAngle_1 = cos(angle_1);
  float sinAngle_1 = sin(angle_1);
  float cosAngle_2 = cos(angle_2);
  float sinAngle_2 = sin(angle_2);


  for (int i = 0 ; i < vertexList.size() - 1 ; ++i) {

    if (version>(startVersion-1) && version < (endVersion)) {

      float[] vertexArr = (float[])vertexList.get(i);
      float v1_x = cosAngle_1*(vertexArr[0]*scaleRatio+rad);
      float v1_y = sinAngle_1*(vertexArr[0]*scaleRatio+rad);
      float v2_x = cosAngle_1*(vertexArr[1]*scaleRatio+rad);
      float v2_y = sinAngle_1*(vertexArr[1]*scaleRatio+rad);
      float v3_x = cosAngle_2*(vertexArr[2]*scaleRatio+rad);
      float v3_y = sinAngle_2*(vertexArr[2]*scaleRatio+rad);
      float v4_x = cosAngle_2*(vertexArr[3]*scaleRatio+rad);
      float v4_y = sinAngle_2*(vertexArr[3]*scaleRatio+rad);

      int colorVersion = (int)(vertexArr[4]);

      PVector mdsNode = (PVector)mdsVersionList.get(colorVersion/2);

      //color quadColor = yuvToRgb(mdsNode, colorVersion, version);
      //color quadColor = searchColor((int)(colorVersion));

      int quadColor = searchColor(mdsNode, colorVersion, version);


      float r1 = vertexArr[0]*scaleRatio+rad;
      float r2 = vertexArr[1]*scaleRatio+rad;
      float r3 = vertexArr[3]*scaleRatio+rad;
      float r4 = vertexArr[2]*scaleRatio+rad;

      float angle_1_ratio = (angle_1 - r_theta)/(angle_1-angle_2);

      if (rMouse>(r1*(1-angle_1_ratio)+r3*angle_1_ratio)
        &&rMouse<(r2*(1-angle_1_ratio)+r4*angle_1_ratio)
        && r_theta>angle_1 && r_theta<angle_2)
      {
        // println(version);
        highlistVersion = colorVersion;
        hightLightState =true;
        // highlistName =
      }

      fill(quadColor);
      stroke(quadColor, 50);
      //if (samplingViewState&&colorVersion%2==1)fill(quadColor, 75);
      quad(v1_x, v1_y, v2_x, v2_y, v3_x, v3_y, v4_x, v4_y);
    }

    drawCnt++;

    if (versionIndex[version]==drawCnt) {

      if (version>(startVersion-1) && version < (endVersion+1)) {

        PVector mdsNode = (PVector)mdsVersionList.get(version/4);
        int rectColor = searchColor(mdsNode, version/2, version/2 );

        fill(rectColor);

        if (version%2==0)
          rect((rad-5) * cosAngle_1 - 1, (rad-5) * sinAngle_1 -1, 2, 2);

        //color nameColor = searchColor(version/2);

        String versionName = (String)versionNameList.get(version);

        int nameColor = searchColor(versionName);
        fill(nameColor, 125);
        int _versionCount = 0;


        pushMatrix();
        translate((180f*scaleRatio + rad) * cos(angle_1 + 0.0f), (180f*scaleRatio + rad) * sin(angle_1 + 0.0f));
        rotate(angle_1);
        textSize(10);
        if (version%2==1) {

          for (int h =  0 ; h < highlightCircosName.size() ; ++h) {

            int[] nameVersion = (int[])(highlightCircosName.get(h));
            //println(nameVersion);
            if (nameVersion[0] == version && nameVersion[1] ==highlistVersion) {
              fill(nameColor, 255);
              break;
            }
          }


          text(versionName, 0, 0);
        }
        rotate(-angle_1);
        popMatrix();


        boolean preCheck=false;
        for (int a = 0 ; a < versionCnt; ++a) {

          String _versionName = (String)versionNameList.get(a);
          if (versionName.equals(_versionName)) {
            if (version<a)preCheck=true;
            _versionCount++;
          }
        }
        textSize(7);
        if (!preCheck&&_versionCount>0)
        {
          if (nameList+nameListScroll>=0&&nameList+nameListScroll<=100)
          {
            rect( -widthC/2 + 15, -height*0.49f+300+nameList-5+nameListScroll, 3, 3);
            fill(255);
            text(versionName, -widthC*0.5f + 25, -height*0.49f+300+nameList+nameListScroll);
            textAlign(RIGHT);
            text(_versionCount, -widthC*0.5f+115, -height*0.49f+300+nameList+nameListScroll);
            textAlign(LEFT);
          }
          nameList+=7;
        }
      }      

      version++;
      drawCnt = 0;

      angle_1 = 2f * PI / (float)(endVersion -startVersion ) * 
        (float)(version -startVersion) - 0.5f*PI;
      angle_2 = 2f * PI / (float)(endVersion -startVersion ) * 
        (float)(version -startVersion +1) - 0.5f*PI;

      cosAngle_1 = cos(angle_1);
      sinAngle_1 = sin(angle_1);
      cosAngle_2 = cos(angle_2);
      sinAngle_2 = sin(angle_2);
    }
  }

  if (!hightLightState)highlistVersion = -2;
  sumNameList=nameList;
}
int sumNameList=0;

int nameList=0;

public void drawMDS() {

  boolean flag = false;
  for (int i = 0 ; i < mdsNodeList.size() ; ++i) {

    PVector mdsNode = (PVector)mdsNodeList.get(i);

    //color mdsColor = yuvToRgb(mdsNode, -1, -1);
    int mdsColor = searchColor(mdsNode, -1, -1);

    fill(mdsColor);

    if (highlistVersion == (int)(mdsNode.z*2) ) {
      textSize(15f);
      String printMdsStr = (String)mdsStrList.get(i);

      text(printMdsStr, mdsNode.x*rad * 0.75f - printMdsStr.length()*2, mdsNode.y*rad * 0.75f);
    }

    textSize(12f);

    //text((String)mdsStrList.get(i), mdsNode.x*rad * 0.75f, mdsNode.y*rad * 0.75f);

    for (int j = 0 ; j < i ; ++j)
    {
      if (abs(((PVector)mdsNodeList.get(j)).x - mdsNode.x) < 0.1f  && abs(((PVector)mdsNodeList.get(j)).y -mdsNode.y) < 0.1f )
      {
        flag = true;
        break;
      }
    } 

    if (flag == false)
    {

      String[] pieces = split((String)mdsStrList.get(i), " ");

      text(pieces[0] + "..", mdsNode.x*rad * 0.75f - 24f, mdsNode.y*rad * 0.75f);
    }
    flag = false;
    //rect(mdsNode.x*rad * 0.75f, mdsNode.y*rad * 0.75f, 2, 2);
  }
}

public int searchColor(int _version) {

  //_version = 80 - _version;

  float r = 0;
  float g = 0;
  float b = 0;

  float v= 1.0f;
  float s= 1.0f;

  float p = 0.0f;
  float q = 0.0f;
  float t = 0.0f;
  float h = PApplet.parseFloat(_version) / PApplet.parseFloat(versionCnt) *6f;
  int i = PApplet.parseInt(h);

  float f = h - i;

  p = v * (1.0f - s);
  q = v * (1.0f - s*f);
  t = v * (1.0f - s*(1.0f - f));

  switch(i) {
  case 0: 
    r = v;     
    g = t;     
    b = p; 
    break;
  case 1: 
    r = q;     
    g = v;     
    b = p; 
    break;
  case 2: 
    r = p;     
    g = v;     
    b = t; 
    break;
  case 3: 
    r = p; 
    g = q; 
    b = v; 
    break;
  case 4: 
    r = t; 
    g = p; 
    b = v; 
    break;
  case 5: 
    r = v; 
    g = p; 
    b = q; 
    break;
  }


  r *=255.0f;
  g *=255.0f;
  b *=255.0f;
  float a = 180.0f;

  if (highlistVersion == _version) {
    a = 255f;
  }
  if (H_flag)a = 255;
  return color(r, g, b, a);
  // return color(b, g,r, a);
}



public int searchColor(PVector _vec, int _mdsVersion, int _version) {

  //_version = 80 - _version;

  float r = 0;
  float g = 0;
  float b = 0;

  float v= 1.0f;
  float s= 1.0f;

  float p = 0.0f;
  float q = 0.0f;
  float t = 0.0f;
  float _angle =  2f*PI * Col_Scale;
  float h = 1;
  if (FousingMDS)h = (-(atan2(_vec.y, _vec.x) + PI + _angle )%(2f*PI)) / PI*3f;
  else h = ((atan2(_vec.y + 0.5f, _vec.x+0.5f) + PI + _angle )%(2f*PI)) / PI*3f;
  int i = PApplet.parseInt(h);

  float f = h - i;

  p = v * (1.0f - s);
  q = v * (1.0f - s*f);
  t = v * (1.0f - s*(1.0f - f));

  switch(i) {
  case 0: 
    r = v;     
    g = t;     
    b = p; 
    break;
  case 1: 
    r = q;     
    g = v;     
    b = p; 
    break;
  case 2: 
    r = p;     
    g = v;     
    b = t; 
    break;
  case 3: 
    r = p; 
    g = q; 
    b = v; 
    break;
  case 4: 
    r = t; 
    g = p; 
    b = v; 
    break;
  case 5: 
    r = v; 
    g = p; 
    b = q; 
    break;
  }


  r *=255.0f;
  g *=255.0f;
  b *=255.0f;
  float a = 180.0f;

  float distance = 50f / sqrt( _vec.x*_vec.x + _vec.y* _vec.y );


  //distance =0;

  float _alpha = ((float)_mdsVersion/ (float)_version*1f);
  float _sat = 1.5f;
  //_alpha = sqrt(_alpha)*255f;
  _alpha = pow(_alpha, 1.5f)*255f;

  if (_alpha<50)_alpha = 50f;

  _sat *= (_alpha/255f);

  if (highlistVersion == _mdsVersion) {
    a = 255f;
    // distance*=2f;
    _sat = 1f;
  }

  if (samplingViewState&&_mdsVersion%2==1) {
    float returnC = max(r, g);
    returnC = max(returnC, b);
    return color((returnC + distance)*_sat, (returnC + distance)*_sat, (returnC + distance)*_sat, a);
  }

  if (H_flag)a = 255;

  return color((r + distance)*_sat, (g + distance)*_sat, (b + distance)*_sat, a);
  // return color(b, g,r, a);
}

public int searchColor(String _name) {

  int _version = 0;
  /*
  for (int i = 0 ; i < versionNameList.size() ; ++i) {
   
   String versionName = (String)versionNameList.get(i);
   
   if (_name.equals(versionName)) {
   _version = (int)(i);
   //_version++;
   break;
   }
   }
   */
  for (int j= 0 ; j < nameRatioCnt ; ++j) {
    if (_name.equals(nameRatioList[j].name)) {
      _version = nameRatioList[j].sortNum;

      break;
    }
  }       

  //_version = 80 - _version;

  float r = 0;
  float g = 0;
  float b = 0;

  float v= 1.0f;
  float s= 1.0f;

  float p = 0.0f;
  float q = 0.0f;
  float t = 0.0f;
  float h = PApplet.parseFloat(sortCnt - _version) / PApplet.parseFloat(sortCnt) *5.0f;
  int i = PApplet.parseInt(h);

  float f = h - i;

  p = v * (1.0f - s);
  q = v * (1.0f - s*f);
  t = v * (1.0f - s*(1.0f - f));

  switch(i) {
  case 0: 
    r = v;     
    g = t;     
    b = p; 
    break;
  case 1: 
    r = q;     
    g = v;     
    b = p; 
    break;
  case 2: 
    r = p;     
    g = v;     
    b = t; 
    break;
  case 3: 
    r = p; 
    g = q; 
    b = v; 
    break;
  case 4: 
    r = t; 
    g = p; 
    b = v; 
    break;
  case 5: 
    r = v; 
    g = p; 
    b = q; 
    break;
  }


  r *=255.0f;
  g *=255.0f;
  b *=255.0f;
  float a = 180.0f;

  // if (highlistVersion == _version) {
  //a = 255f;
  //}

  return color(r, g, b, 255);
  // return color(b, g,r, a);
}



public int yuvToRgb(PVector _vec, int _mdsVersion, int _version) {
  float _x;
  float _y;
  //float yValue= 1.164*(16- 16);
  float yValue= 0;
  float _sat=1.5f;
  float _distant=2.5f;
  //float _angle=PI*1.9f/4f;
  //float _angle = 2f*PI*(float)mouseX / (float)widthC;
  //float _angle = 2f*PI*0.4f;
  float _angle =  2f*PI * Col_Scale;
  float _light=200f;


  //_x=_vec.x*100f;
  //_y=_vec.y*100f;

  float range = 500f;

  _x = (_vec.x *range )*cos(_angle)-(_vec.y *range)*sin(_angle);
  _y = (_vec.x *range)*sin(_angle)+(_vec.y *range)*cos(_angle);

  float _alpha =240f;

  if (!H_flag&&highlistVersion == _mdsVersion || _mdsVersion ==-1) {
    _sat =2.5f;
    _alpha = 255f;
  }
  else {
    _alpha = ((float)_mdsVersion/ (float)_version*1f);

    //_alpha = sqrt(_alpha)*255f;
    _alpha = pow(_alpha, 1.5f)*255f;

    if (_alpha<30)_alpha = 30f;

    _sat *= (_alpha/255f);
    //_sat = 1;

    _alpha = 180f;
    //_alpha *= _alpha;
    //_sat =(float)_mdsVersion/ (float)_version*0.6f + 0.6f;
  }

  if (H_flag)_alpha = 255f;

  return color(((_light-1.596f * _y))*_sat, 
  ((_light-(-0.813f * _y - 0.391f * _x )))*_sat, 
  ((_light- 2.018f * _x ))*_sat, _alpha);
  //return color(200f ,0f,0.5f,255f);
}

int startVersion = 0;
int endVersion = 0;

public void keyPressed() {
  if (keyCode == SHIFT) {
    samplingViewState = !samplingViewState;
  }
   
    if (keyCode == ENTER || keyCode == RETURN) {
          savePdf = true;

    }
  
}



////////////////////////////////////////
//                  UI                //


/**
 * Button. 
 * 
 * Click on one of the colored squares in the 
 * center of the image to change the color of 
 * the background. 
 */

int rectX, rectY;      // Position of square button
int circleX, circleY;  // Position of circle button
int rectSize = 20;     // Diameter of rect
int circleSize = 93;   // Diameter of circle
int rectColor, circleColor, baseColor;
int rectHighlight, circleHighlight;
int currentColor;

boolean rectOver_1, rectOver_2, rectOver_3, rectOver_4, rectOver_5, rectOver_6, rectOver_7, rectOver_8, rectOver_9, rectOver_10, rectOver_bg = false;

boolean pressed_1, pressed_2, pressed_3, pressed_4, pressed_8;
boolean pressed_5 = false;
boolean pressed_6 = true;
boolean pressed_7= true;
boolean pressed_9= false;
boolean pressed_bg = false;
boolean FousingMDS = false;

MRect r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r_bg;
MRect r_bg2, r_bg3, r_bg4, r_bg5;

float xTrans = -30;
float yTrans = -30;

float Time_1, Time_2, H_Scale, C_Scale, Col_Scale;
boolean H_flag = true;
boolean C_flag = true;
boolean M_flag = true;

public void uiSetup() {

  rectColor = color(0);
  rectHighlight = color(51);
  circleColor = color(255);
  circleHighlight = color(204);
  baseColor = color(102);
  currentColor = baseColor;
  circleX = widthC/2+circleSize/2+10;
  circleY = height/2;
  rectX = widthC/2-rectSize-10;
  rectY = height/2-rectSize/2;
  ellipseMode(CENTER);

  r_bg = new MRect(135, 40.0f, 40, 40, 0.0f, 1.0f);
  r_bg2 = new MRect(135, 40.0f, 35, 84, 0.0f, 1.0f);
  r_bg3 = new MRect(135, 40.0f, 35, 123, 0.0f, 1.0f);
  r_bg4 = new MRect(135, 40.0f, 35, 162, 0.0f, 1.0f);

  r_bg5 = new MRect(135, 40.0f, 115, 201, 0.0f, 1.0f);


  r1 = new MRect(15, 50.0f, 15, 60, 0.0f, 1.0f);
  r2 = new MRect(15, 150.0f, 15, 60, 0.0f, 1.0f);

  r3 = new MRect(15, 100.0f, 15, 100, 0.0f, 1.0f);
  r4 = new MRect(15, 100.0f, 15, 140, 0.0f, 1.0f);
  r5 = new MRect(15, 50.0f, 15, 203, 0.0f, 1.0f);
  r6 = new MRect(15, 50.0f, 15, 226, 0.0f, 1.0f);
  r7 = new MRect(15, 50.0f, 15, 249, 0.0f, 1.0f);
  r8 = new MRect(15, 50.0f, 15, 180, 0.0f, 1.0f);
  r9 = new MRect(15, 50.0f, 15, 272, 0.0f, 1.0f);
  r10 = new MRect(15, 50.0f, 15, 295, 0.0f, 1.0f);

  r_bg.xpos += xTrans;
  r1.xpos += xTrans;
  r2.xpos += xTrans;
  r3.xpos += xTrans;
  r4.xpos += xTrans;
  r5.xpos += xTrans;
  r6.xpos += xTrans;
  r7.xpos += xTrans;
  r8.xpos += xTrans;
  r9.xpos += xTrans;
  r10.xpos += xTrans;


  r_bg.ypos += yTrans;
  r1.ypos += yTrans;
  r2.ypos += yTrans;
  r3.ypos += yTrans;
  r4.ypos += yTrans;
  r5.ypos += yTrans;
  r6.ypos += yTrans;
  r7.ypos += yTrans;
  r8.ypos += yTrans;
  r9.ypos += yTrans;
  r10.ypos += yTrans;

  r_bg2.xpos += xTrans;
  r_bg2.ypos += yTrans;

  r_bg3.xpos += xTrans;
  r_bg3.ypos += yTrans;

  r_bg4.xpos += xTrans;
  r_bg4.ypos += yTrans;

  r_bg5.xpos += xTrans;
  r_bg5.ypos += yTrans;
}

float UI1data = 0f;
float UI2data = 1f;
public void uIDraw() {


  translate(-0.5f*widthC, -0.5f*height);


  fill(80, 150);
  noStroke();
  r_bg.display();

  r_bg2.display();
  r_bg3.display();
  r_bg4.display();

  r_bg5.display();


  /*
  if (pressed_bg == true)
   {
   //r_bg.move(r_bg.xpos+(mouseX-pmouseX), r_bg.ypos+(mouseY-pmouseY), 0);
   float deltaMouseX = mouseX-pmouseX;
   float deltaMouseY = mouseY-pmouseY;
   
   xTrans += deltaMouseX;
   yTrans += deltaMouseX;
   
   r_bg.xpos += deltaMouseX;
   r1.xpos += deltaMouseX;
   r2.xpos += deltaMouseX;
   r3.xpos += deltaMouseX;
   r4.xpos += deltaMouseX;
   r5.xpos += deltaMouseX;
   r6.xpos += deltaMouseX;
   r7.xpos += deltaMouseX;
   r8.xpos += deltaMouseX;
   
   r_bg.ypos += deltaMouseY;
   r1.ypos += deltaMouseY;
   r2.ypos += deltaMouseY;
   r3.ypos += deltaMouseY;
   r4.ypos += deltaMouseY;
   r5.ypos += deltaMouseY;
   r6.ypos += deltaMouseY;
   r7.ypos += deltaMouseY;
   r8.ypos += deltaMouseY;
   }
   */


  fill(250);
  textSize(10);
  text("Time LIne", 50+xTrans, r1.ypos - 5);

  fill(50);
  //stroke(255);

  fill(100);
  rect(50 + xTrans, r1.ypos, 115, 15);
  fill(150);
  rect(r1.xpos, r1.ypos, r2.xpos - r1.xpos, 15);
  //line(50+xTrans, r1.ypos+7.5f, 150+xTrans, r1.ypos+7.5f);
  fill(250);
  r1.display();
  if (pressed_1 == true)
  {
    r1.move(mouseX-r1.w/2, r1.ypos, 30);
    if (r1.xpos < 50 + xTrans)
    {
      r1.xpos = 50 + xTrans;
    }
    if (r1.xpos > 150+ xTrans)
    {
      r1.xpos = 150+ xTrans;
    }

    if (r1.xpos > (r2.xpos-3))r1.xpos = r2.xpos - 3;
    UI1data = (r1.xpos -50f -  xTrans)/100f;
    UI1data = (UI1data/2)*2f;

    // println(UI1data);
  }

  // text("Circos Scale Transform", 50, 90);
  fill(250);
  r2.display();
  if (pressed_2 == true)
  {
    r2.move(mouseX-r2.w/2, r2.ypos, 30);
    if (r2.xpos < 50+ xTrans)
    {
      r2.xpos = 50+ xTrans;
    }
    if (r2.xpos > 150+ xTrans)
    {
      r2.xpos = 150+ xTrans;
    }
    if (r1.xpos > (r2.xpos-3))r2.xpos = (r1.xpos+3);
    UI2data = (r2.xpos -50f -  xTrans)/100f;
    UI2data = (UI2data/2)*2f;
  }

  fill(100);
  rect(50 + xTrans, r3.ypos, 115, 15);
  fill(150);
  rect(r3.xpos, r3.ypos, (150 + xTrans)-r3.xpos+15, 15);


  fill(250);

  text("History Scale", 50+xTrans, r3.ypos - 5);
  fill(250);
  r3.display();
  if (pressed_3 == true)
  {
    r3.move(mouseX-r2.w/2, r3.ypos, 30);
    if (r3.xpos < 50+ xTrans)
    {
      r3.xpos = 50+ xTrans;
    }
    if (r3.xpos > 150+ xTrans)
    {
      r3.xpos = 150+ xTrans;
    }
  }


  fill(100);
  rect(50 + xTrans, r4.ypos, 115, 15);
  fill(150);
  rect(r4.xpos, r4.ypos, (150 + xTrans)-r4.xpos+15, 15);


  fill(250);
  text("Circos Scale", 50+xTrans, r4.ypos - 5);
  fill(250);
  r4.display();
  if (pressed_4 == true)
  {
    r4.move(mouseX-r2.w/2, r4.ypos, 30);
    if (r4.xpos < 50+ xTrans)
    {
      r4.xpos = 50+ xTrans;
    }
    if (r4.xpos > 150+ xTrans)
    {
      r4.xpos = 150+ xTrans;
    }
  }

  fill(100);
  rect(50 + xTrans, r8.ypos, 115, 15);
  fill(150);
  rect(r8.xpos, r8.ypos, (150 + xTrans)-r8.xpos+15, 15);


  fill(250);
  text("Color Scale", 50+xTrans, r8.ypos - 5);
  fill(250);
  r8.display();
  if (pressed_8 == true)
  {
    r8.move(mouseX-r8.w/2, r8.ypos, 30);
    if (r8.xpos < 50+ xTrans)
    {
      r8.xpos = 50+ xTrans;
    }
    if (r8.xpos > 150+ xTrans)
    {
      r8.xpos = 150+ xTrans;
    }
  }



  if (pressed_5 == false)
    fill(100);
  else
    fill(250);

  r5.display();


  fill(250);
  text("Highlighting", 70+xTrans, r8.ypos + 35);

  if (pressed_6 == false)
    fill(100);
  else
    fill(250);

  r6.display();

  fill(250);
  text("Circos View", 70+xTrans, r5.ypos + 35);

  if (pressed_7 == false)
    fill(100);
  else
    fill(250);

  r7.display();

  fill(250);
  text("MDS View", 70+xTrans, r6.ypos + 35);

  if (pressed_9 == false)
    fill(100);
  else
    fill(250);

  r9.display();

  fill(250);
  text("Focusing Circos", 70+xTrans, r7.ypos + 35);


  if (FousingMDS == false)
    fill(100);
  else
    fill(250);

  r10.display();

  fill(250);
  text("Focusing MDS", 70+xTrans, r9.ypos + 35);



  noStroke();
  fill(200);
  textSize(7);


  Time_1 = (r1.xpos-50-xTrans)/100f;
  Time_2 = (r2.xpos-50-xTrans)/100f;  
  H_Scale = (r3.xpos-50-xTrans)/100f;
  C_Scale = (r4.xpos-50-xTrans)/100f;
  Col_Scale = (r8.xpos-50-xTrans)/100f;
  H_flag = pressed_5;
  C_flag = pressed_6;
  M_flag = pressed_7;


  startVersion = (int)((float)Time_1 * (float)versionCnt);
  endVersion = (int)((float)Time_2 * (float)versionCnt);





  rad = 180f*(C_Scale +0.5f);


  scaleRatio = H_Scale + 0.5f - (rad /180f - 1f );
}

public void UIupdate(float x, float y) {
  if ( r1.overRect() ) {
    rectOver_1 = true;
    rectOver_bg = false;
  } 
  else if ( r2.overRect() ) {
    rectOver_2 = true;
    rectOver_bg = false;
  } 
  else if ( r3.overRect() ) {
    rectOver_3 = true;
    rectOver_bg = false;
  } 
  else if ( r4.overRect() ) {
    rectOver_4 = true;
    rectOver_bg = false;
  } 
  else if ( r5.overRect() ) {
    rectOver_5 = true;
    rectOver_bg = false;
  } 
  else if ( r6.overRect() ) {
    rectOver_6 = true;
    rectOver_bg = false;
  } 
  else if ( r7.overRect() ) {
    rectOver_7 = true;
    rectOver_bg = false;
  } 
  else if ( r8.overRect() ) {
    rectOver_8 = true;
    rectOver_bg = false;
  }
  else if ( r9.overRect() ) {
    rectOver_9 = true;
    rectOver_bg = false;
  }  
  else if ( r10.overRect() ) {
    rectOver_10 = true;
    rectOver_bg = false;
  }  
  //else if ( overRect(r_bg.xpos, r_bg.ypos, r_bg.w, r_bg.h) && !rectOver_1 && !rectOver_2 && !rectOver_3 && !rectOver_4 && !rectOver_5 && !rectOver_6 && !rectOver_7 )  
  //{
  //rectOver_bg = true;
  //} 
  else {
    rectOver_1 = false;
    rectOver_2 = false;
    rectOver_3 = false;
    rectOver_4 = false;
    rectOver_5 = false;
    rectOver_6 = false;
    rectOver_7 = false;
    rectOver_8 = false;
    rectOver_9 = false;
    rectOver_bg = false;
    rectOver_10 = false;
  }
}




public void mouseMoved() {
  UIupdate(mouseX, mouseY);
}

public void mousePressed() {
  UIupdate(mouseX, mouseY);
  if (rectOver_1) {
    pressed_1 = true;
  }
  if (rectOver_2) {
    pressed_2 = true;
  }
  if (rectOver_3) {
    pressed_3 = true;
  }
  if (rectOver_4) {
    pressed_4 = true;
  }
  if (rectOver_5) {
    pressed_5 = !pressed_5;
  }
  if (rectOver_6) {
    pressed_6 = !pressed_6;
  }
  if (rectOver_7) {
    pressed_7 = !pressed_7;
  }
  if (rectOver_8) {
    pressed_8 = !pressed_8;
  }
  if (rectOver_9) {
    pressed_9 = !pressed_9;
  }

  if (rectOver_10) {
    FousingMDS = !FousingMDS;
  }

  if (rectOver_bg) {
    pressed_bg = true;
  }
}
public void mouseReleased() {
  pressed_1 = false;
  pressed_2 = false;
  pressed_3 = false;
  pressed_4 = false;
  pressed_8 = false;
  pressed_bg = false;
}




int textLength=0;
int lastTextLength=0;
int textY=10;
float textRectY=5;
int scrollHeight=20;

public void textDraw() {
  int distance=0;
  int rectY=0;
  int preRectY=0;
  textLength=0;
  //textAlign(CENTER);
  boolean scrollInit=false;
  for (int index=0; index<lastText.length;index++)
  {

    if (textColorSelect()&&!scrollInit) {
      scrollInit=true;
      textY=(int)(-((float)textLength/(float)(lastTextLength))*lastDistance+10+10);
      textRectY=(height-scrollHeight)*(float)(-((float)textY)/(float)(lastDistance))+5;
    }
    text(lastText[index], width-330, textY+distance, 300, 100000);


    distance+=10*((int)(lastText[index].length()/60))+10;

    textLength+=lastText[index].length();
    rectY=(int)(((float)textLength/(float)(lastTextLength))*height);
    if (rectY!=preRectY)
    {
      rect(width-10, preRectY, 10, rectY-preRectY);
      preRectY=rectY;
    }
  }
  fill(50);
  rect(width-20, 5, 10, height-5);
  ellipse(width-15, 5, 10, 10);
  ellipse(width-15, height-5, 10, 10);
  fill(100);
  rect(width-18, textRectY, 6, scrollHeight);
  ellipse(width-15, textRectY, 6, 6);
  ellipse(width-15, textRectY+scrollHeight, 6, 6);
  // print(textY+", "+lastDistance+", "+textRectY+"\n");
}

public boolean textColorSelect() {
  int colorChoose=(int)((((float)textLength/(float)(lastTextLength))
    *(lastColorArr.length)));



  if (lastColorHighListArr[colorChoose]==(highlistVersion/2)) {
    fill(lastColorArr[colorChoose], 255);
    // print(highlistVersion+"\n");

    return true;
  }

  fill(lastColorArr[colorChoose], 100);

  return false;
}


public void mouseWheel(int delta) {
  if (mouseX<160&&mouseY>280&&mouseY<400)
  {
    nameListScroll+=-delta*10;
    if (nameListScroll>10)
      nameListScroll=10;
    if (nameListScroll<-(sumNameList-100))
      nameListScroll=-(sumNameList-100);
  }
  if (mouseX<width-330)
    return;
  textY+=-delta*50;
  if (textY>10)
    textY=10;
  if (textY<-lastDistance)
    textY=-lastDistance;
  textRectY=(height-scrollHeight)*(float)(-((float)textY)/(float)(lastDistance))+5;
  //rect(1280, textRectY, 20, 300);
}

class MRect 
{
  float w; // single bar widthC
  float xpos; // rect xposition
  float h; // rect height
  float ypos ; // rect yposition
  float d; // single bar distance
  float t; // number of bars

  MRect(float iw, float ixp, float ih, float iyp, float id, float it) {
    w = iw;
    xpos = ixp;
    h = ih;
    ypos = iyp;
    d = id;
    t = it;
  }

  public void move (float posX, float posY, float damping) {
    ypos = posY;
    xpos = posX;
  }

  public void display() {
    for (int i=0; i<t; i++) {
      //fill(10);
      rect(xpos+(i*(d+w)), ypos, w, h);
    }
  }

  public boolean overRect() {
    if (mouseX >= xpos && mouseX <= xpos+w && 
      mouseY >= ypos && mouseY <= ypos+h) {
      return true;
    } 
    else {
      return false;
    }
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "HistoryCircle" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
